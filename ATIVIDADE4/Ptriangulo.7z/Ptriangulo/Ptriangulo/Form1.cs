﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void TxtB_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(txtB, "");
            if(!Double.TryParse(txtB.Text, out ladoB) || ladoB < 0)
            {
                errorProvider2.SetError(txtB, "valor de B inválido");
                txtB.Focus();
            }
        }

        private void TxtC_TextChanged(object sender, EventArgs e)
        {
            errorProvider3.SetError(txtC, "");
            if(!Double.TryParse(txtC.Text, out ladoC) || ladoC < 0)
            {
                errorProvider3.SetError(txtC, "valor C inválido");
                txtC.Focus();
            }
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            if ((Math.Abs(ladoB - ladoC) < ladoA && ladoA < (ladoB + ladoC)) && (Math.Abs(ladoA - ladoC) < ladoB && ladoB < (ladoA + ladoC)) &&
                    (Math.Abs(ladoA - ladoB) < ladoC && ladoC < (ladoA + ladoB)))
            {
                if (ladoA == ladoB && ladoB == ladoC && ladoC == ladoA)
                    MessageBox.Show("triângulo equilátero");
                else if (ladoA != ladoB && ladoB != ladoC && ladoC != ladoA)
                    MessageBox.Show("triângulo escaleno");
                else
                    MessageBox.Show("triangulo isósceles");

            }
            else
            {
                MessageBox.Show("não é triangulo");
            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtA.Text = "";
            txtB.Text = ""; 
            txtC.Text="";
            errorProvider1.SetError(txtA, "");
            errorProvider2.SetError(txtB, "");
            errorProvider3.SetError(txtC, "");
            txtA.Focus();
        }

        private void TxtA_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void TxtA_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtA, "");
            if(!Double.TryParse(txtA.Text, out ladoA)|| (ladoA<0)){
                errorProvider1.SetError(txtA, "valor de A inválido");
                txtA.Focus();
            }
        }
    }
}
